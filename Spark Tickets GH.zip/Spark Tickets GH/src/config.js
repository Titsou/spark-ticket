module.exports = {
  // Embed Colors
  embedColor: "#34B680",
  errorColor: "#34B680",
  successColor: "#34B680",

  // Emojis
  emojis: {
    ticket: "🎫",
    success: "✅",
    error: "🚫",
  },
};
