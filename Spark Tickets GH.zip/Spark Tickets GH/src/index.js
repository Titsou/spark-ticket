require("dotenv/config");
require("colors");

const { Client, ActivityType, GatewayIntentBits, Partials } = require("discord.js");
const { readdirSync } = require("fs");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
  ],
  partials: [Partials.Channel, Partials.GuildMember],
});
client.commands = new Map();
client.buttons = new Map();
client.config = require("./config.js");

function setBotActivities() {
    client.user.setActivity({
        type: ActivityType.Listening,
        name: `Spark Tickets!`
    })

    const serverCount = client.guilds.cache.size;
    const commandsCount = client.commands.size;
    const members = client.users.cache.size;
    const channels = client.channels.cache.size;
    
    setTimeout(() => {
        client.user.setActivity({
            type: ActivityType.Watching,
            name: `${client.guilds.cache.reduce((a,b) => a+b.memberCount, 0)} members`
        });

        setTimeout(() => {
            client.user.setActivity({
                type: ActivityType.Listening,
                name: `${serverCount} Servers!`
            });
            setTimeout(() => {
                setBotActivities();
            }, 10000);
        }, 10000);
    }, 10000);
}

client.on('ready', async () => {
  setBotActivities();
});

const handlerFolder = readdirSync("./src/handlers").filter((f) =>
  f.endsWith(".js")
);
for (const handler of handlerFolder) {
  const handlerFile = require(`./handlers/${handler}`);
  handlerFile(client);
}

client.login(process.env.Token);
